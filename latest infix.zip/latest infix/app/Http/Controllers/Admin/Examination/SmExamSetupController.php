<?php

namespace App\Http\Controllers\Admin\Examination;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SmExamSetupController extends Controller
{
    // 
}
