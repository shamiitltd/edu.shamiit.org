<?php

namespace App\Http\Controllers;
use App\SmNews;
use App\ApiBaseMethod;
use App\SmNewsCategory;
use App\SmGeneralSettings;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;


class SmNewsController extends Controller
{

  //

}